document.addEventListener('DOMContentLoaded', function () {
    const loginBtn = document.getElementById('loginBtn');
    const idInput = document.getElementById('id');
    const passwordInput = document.getElementById('password');

    loginBtn.addEventListener('click', function (event) {
        event.preventDefault();  // Impede o comportamento padrão do botão (não envia um formulário)

        // Verifica se os campos ID e senha estão preenchidos
        if (!idInput.value.trim() || !passwordInput.value.trim()) {
            alert('Por favor, digite seu ID e senha para continuar');
            if (!idInput.value.trim()) {
                idInput.focus();
            } else {
                passwordInput.focus();
            }
            return; // Impede o redirecionamento caso algum campo esteja vazio
        }

        alert('Login realizado com sucesso!');

        // Redireciona para a página de consulta após login bem-sucedido
        window.location.href = '/src/consulta_produtos_admin/consulta.html'; // Redirecionamento

        // Limpa os campos de ID e senha
        idInput.value = '';
        passwordInput.value = '';

        // Foca no campo ID novamente
        idInput.focus();
    });
});
