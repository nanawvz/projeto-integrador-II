// Função que realiza a consulta de produto com base no ID
function consultarProduto() {
    let id = document.getElementById('id').value.trim(); // Pega o ID do campo de entrada e remove espaços extras

    // Recupera a lista de produtos do localStorage
    let produtos = JSON.parse(localStorage.getItem('produtos')) || [];

    // Limpa a área de detalhes do produto (se estiver visível)
    document.getElementById('produto-info')?.remove();

    // Limpa a lista de produtos exibida antes de qualquer nova consulta
    document.getElementById('produtos-list').innerHTML = '';

    // Esconde a lista de produtos para evitar que ela seja exibida durante a consulta por ID
    document.getElementById('produtos-lista').classList.add("hidden");

    // Verifica se o ID foi inserido
    if (id === '') {
        // Se o ID não for fornecido, exibe todos os produtos cadastrados
        showMessage("Exibindo todos os produtos cadastrados.", "success");
        exibirProdutos(produtos); // Exibe a lista de produtos
        return; // Não prossegue com a busca por ID
    }

    // Procura o produto pelo ID
    let produtoEncontrado = produtos.find(produto => produto.id === id); // A comparação é feita com o ID como string

    // Se o produto for encontrado, exibe as informações
    if (produtoEncontrado) {
        showMessage("Produto encontrado com sucesso!", "success");
        exibirProdutoDetalhes(produtoEncontrado); // Exibe os detalhes do produto encontrado
    } else {
        // Se o produto não for encontrado, exibe uma mensagem de erro
        showMessage("Produto não encontrado. Tente novamente.", "error");
    }
}

// Exibe todos os produtos cadastrados
function exibirProdutos(produtos) {
    const listaProdutos = document.getElementById('produtos-list');
    listaProdutos.innerHTML = ''; // Limpa qualquer conteúdo anterior

    if (produtos.length === 0) {
        listaProdutos.innerHTML = "<p>Nenhum produto cadastrado.</p>"; // Exibe mensagem caso não haja produtos
        return;
    }

    // Exibe cada produto na lista
    produtos.forEach(produto => {
        const produtoItem = document.createElement('li');
        produtoItem.innerHTML = `
            <strong>ID:</strong> ${produto.id} <br>
            <strong>Nome:</strong> ${produto.nome} <br>
            <strong>Descrição:</strong> ${produto.descricao} <br>
            <strong>Preço:</strong> ${produto.preco} <br>
            <strong>Estoque:</strong> ${produto.estoque} <br><br>
        `;
        listaProdutos.appendChild(produtoItem); // Adiciona o produto à lista
    });

    // Torna visível a lista de produtos e o título "Produtos Cadastrados"
    document.getElementById('produtos-lista').classList.remove("hidden");
}

// Exibe os detalhes do produto encontrado
function exibirProdutoDetalhes(produto) {
    const produtoDetalhes = `
        <strong>ID:</strong> ${produto.id} <br>
        <strong>Nome:</strong> ${produto.nome} <br>
        <strong>Descrição:</strong> ${produto.descricao} <br>
        <strong>Preço:</strong> ${produto.preco} <br>
        <strong>Estoque:</strong> ${produto.estoque} <br><br>
    `;

    const produtoInfo = document.getElementById('produto-info');
    if (!produtoInfo) {
        const newProdutoInfo = document.createElement('div');
        newProdutoInfo.id = 'produto-info';
        newProdutoInfo.innerHTML = produtoDetalhes;
        document.body.appendChild(newProdutoInfo); // Exibe na tela
    } else {
        produtoInfo.innerHTML = produtoDetalhes; // Atualiza caso já exista
    }
}

// Exibe uma mensagem na tela
function showMessage(message, type) {
    const messageContainer = document.getElementById('message');
    
    messageContainer.textContent = message;
    messageContainer.className = 'message ' + type;
    messageContainer.style.display = 'block';

    setTimeout(function() {
        messageContainer.style.display = 'none';
    }, 3000);  // A mensagem desaparece após 3 segundos
}

// Adiciona o ouvinte de evento para o botão de consulta
document.getElementById('consultarBtn').addEventListener('click', consultarProduto);
