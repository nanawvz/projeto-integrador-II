document.getElementById("produto-form").addEventListener("submit", function (event) {
    event.preventDefault();

    const id = document.getElementById("id").value;
    const nome = document.getElementById("nome").value;
    const descricao = document.getElementById("descricao").value;
    const preco = document.getElementById("preco").value;
    const estoque = document.getElementById("estoque").value;

    const produto = {
        id: id,
        nome: nome,
        descricao: descricao,
        preco: preco,
        estoque: estoque
    };

    let produtos = JSON.parse(localStorage.getItem("produtos")) || [];
    const produtoIndex = produtos.findIndex(prod => prod.id === id);
    
    if (produtoIndex > -1) {
        produtos[produtoIndex] = produto;
    } else {
        produtos.push(produto);
    }

    localStorage.setItem("produtos", JSON.stringify(produtos));
    alert("Produto salvo com sucesso!");
    document.getElementById("produto-form").reset();
    exibirProdutos();
});

function editarProduto() {
    const id = document.getElementById("id").value;
    
    if (!id) {
        alert("Por favor, digite um ID para editar.");
        return;
    }

    let produtos = JSON.parse(localStorage.getItem("produtos")) || [];
    const produtoIndex = produtos.findIndex(prod => prod.id === id);
    
    if (produtoIndex === -1) {
        alert("Produto não encontrado!");
        return;
    }

    if (confirm("Tem certeza que deseja editar este produto?")) {
        produtos[produtoIndex] = {
            id: id,
            nome: document.getElementById("nome").value,
            descricao: document.getElementById("descricao").value,
            preco: document.getElementById("preco").value,
            estoque: document.getElementById("estoque").value
        };

        localStorage.setItem("produtos", JSON.stringify(produtos));
        alert("Produto editado com sucesso!");
        exibirProdutos();
    }
}

function excluir() {
    const id = document.getElementById("id").value;
    
    if (!id) {
        alert("Por favor, digite um ID para excluir.");
        return;
    }

    let produtos = JSON.parse(localStorage.getItem("produtos")) || [];
    const produtoIndex = produtos.findIndex(prod => prod.id === id);
    
    if (produtoIndex === -1) {
        alert("Produto não encontrado!");
        return;
    }

    if (confirm("Tem certeza que deseja excluir este produto?")) {
        produtos = produtos.filter(produto => produto.id !== id);
        localStorage.setItem("produtos", JSON.stringify(produtos));
        alert("Produto excluído com sucesso!");
        document.getElementById("produto-form").reset();
        exibirProdutos();
    }
}

function exibirProdutos() {
    const produtos = JSON.parse(localStorage.getItem("produtos")) || [];
    const produtosLista = document.getElementById("produtos-list");
    produtosLista.innerHTML = '';

    if (produtos.length === 0) {
        produtosLista.innerHTML = "<p>Nenhum produto cadastrado.</p>";
    } else {
        produtos.forEach(produto => {
            const novoProduto = document.createElement("li");
            novoProduto.innerHTML = `
                <strong>ID:</strong> ${produto.id} <br>
                <strong>Nome:</strong> ${produto.nome} <br>
                <strong>Descrição:</strong> ${produto.descricao} <br>
                <strong>Preço:</strong> ${produto.preco} <br>
                <strong>Estoque:</strong> ${produto.estoque} <br><br>
            `;
            produtosLista.appendChild(novoProduto);
        });
    }

    document.getElementById("produtos-lista").classList.remove("hidden");
}

document.getElementById("id").addEventListener("blur", function() {
    const id = document.getElementById("id").value;
    const produtos = JSON.parse(localStorage.getItem("produtos")) || [];
    const produto = produtos.find(prod => prod.id === id);
    const submitBtn = document.querySelector("#produto-form button[type='submit']");

    if (produto) {
        document.getElementById("nome").value = produto.nome;
        document.getElementById("descricao").value = produto.descricao;
        document.getElementById("preco").value = produto.preco;
        document.getElementById("estoque").value = produto.estoque;
        submitBtn.textContent = "Atualizar";
    } else {
        document.getElementById("nome").value = '';
        document.getElementById("descricao").value = '';
        document.getElementById("preco").value = '';
        document.getElementById("estoque").value = '';
        submitBtn.textContent = "Salvar";
    }
});

document.addEventListener('DOMContentLoaded', function() {
    exibirProdutos();
});