document.addEventListener('DOMContentLoaded', function () {

    function togglePassword() {
        const passwordInput = document.getElementById('senha');
        const passwordIcon = document.getElementById('togglePassword').querySelector('i');

        const type = passwordInput.type === 'password' ? 'text' : 'password';
        passwordInput.type = type;
        passwordIcon.classList.toggle('fa-eye-slash');
        passwordIcon.classList.toggle('fa-eye');
    }

    
    function handleLogin(event) {
        event.preventDefault();

        const email = document.getElementById('email').value;
        const senha = document.getElementById('senha').value;

        if (email && senha) {
            alert('Login realizado com sucesso!');
            document.getElementById('email').value = '';
            document.getElementById('senha').value = '';
        } else {
            alert('Por favor, preencha todos os campos.');
        }
    }

   
    function handleVoltar(event) {
        event.preventDefault(); 
        window.location.href = "../tela-login-admin/admin.html";
    }


    document.getElementById('togglePassword').addEventListener('click', togglePassword);

   
    document.querySelector('form').addEventListener('submit', handleLogin);

  
    document.querySelector('.voltar').addEventListener('click', handleVoltar);
});
